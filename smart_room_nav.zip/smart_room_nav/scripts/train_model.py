#!/usr/bin/env python3

import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib
import os

def main():
    # Locate dataset in same folder
    data_path = os.path.join(os.path.dirname(__file__), 'room_data.csv')
    df = pd.read_csv(data_path)

    # One-hot encode features
    X = pd.get_dummies(df[['time_of_day', 'task_type']])
    y = df['target_room']

    # Train model
    model = DecisionTreeClassifier()
    model.fit(X, y)

    # Save model
    model_path = os.path.join(os.path.dirname(__file__), 'room_decision_model.pkl')
    joblib.dump(model, model_path)

    print(f"✅ Model trained and saved to: {model_path}")
    print(f"📊 Feature columns: {list(X.columns)}")

if __name__ == '__main__':
    main()
