#!/usr/bin/env python3

import rospy
import pandas as pd
from smart_room_nav.msg import TaskInput
from std_msgs.msg import String
import joblib  # For loading the trained ML model

class DecisionNode:
    def __init__(self):
        rospy.init_node('decision_node')
        rospy.Subscriber('/task_input', TaskInput, self.callback)
        self.pub = rospy.Publisher('/navigation_goal', String, queue_size=10)

        # Load the trained Decision Tree model
        model_path = '/home/mughuntha/catkin_ws/src/smart_room_nav/scripts/room_decision_model.pkl'
        self.model = joblib.load(model_path)
        rospy.loginfo("DecisionNode started. Model loaded.")

    def callback(self, msg):
        try:
            input_dict = {
                "time_of_day": msg.time_of_day,
                "temperature": msg.temperature,
                "humidity": msg.humidity,
                "task_type": msg.task_type
            }

            input_df = pd.DataFrame([input_dict])

            # One-hot encode like training time
            input_df = pd.get_dummies(input_df)

            # Add any missing columns
            for col in self.model.feature_names_in_:
                if col not in input_df.columns:
                    input_df[col] = 0

            # Arrange in same order
            input_df = input_df[self.model.feature_names_in_]

            room = self.model.predict(input_df)[0]
            rospy.loginfo(f"[DecisionNode] Predicted Room: {room}")
            self.pub.publish(room)

        except Exception as e:
            rospy.logerr(f"Error in callback: {e}")

if __name__ == '__main__':
    try:
        node = DecisionNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
