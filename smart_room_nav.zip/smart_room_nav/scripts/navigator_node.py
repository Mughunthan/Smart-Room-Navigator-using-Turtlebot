#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib

# Predefined goal poses for rooms
ROOM_GOALS = {
    "kitchen": {"x": 1.0, "y": 1.5, "yaw": 0.0},
    "living_room": {"x": -1.0, "y": -2.0, "yaw": 0.0}
}

class NavigatorNode:
    def __init__(self):
        rospy.init_node('navigator_node')
        self.sub = rospy.Subscriber('/navigation_goal', String, self.room_callback)


        # Set up the action client to move_base
        self.move_base_client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        rospy.loginfo("Waiting for move_base action server...")
        self.move_base_client.wait_for_server()
        rospy.loginfo("Connected to move_base action server.")

        rospy.loginfo("NavigatorNode is ready and waiting for room predictions...")

    def room_callback(self, msg):
        room = msg.data
        if room not in ROOM_GOALS:
            rospy.logwarn("Unknown room: %s", room)
            return

        goal_coords = ROOM_GOALS[room]
        rospy.loginfo(f"[NavigatorNode] Navigating to: {room}")
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()

        goal.target_pose.pose.position.x = goal_coords["x"]
        goal.target_pose.pose.position.y = goal_coords["y"]
        goal.target_pose.pose.position.z = 0.0
        goal.target_pose.pose.orientation.w = 1.0

        self.move_base_client.send_goal(goal)
        self.move_base_client.wait_for_result()
        rospy.loginfo(f"[NavigatorNode] Arrived at: {room}")

if __name__ == '__main__':
    try:
        NavigatorNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
