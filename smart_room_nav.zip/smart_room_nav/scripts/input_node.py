#!/usr/bin/env python3

import rospy
from smart_room_nav.msg import TaskInput  # Custom message: string time_of_day, int32 temperature, int32 humidity

def input_node():
    rospy.init_node('input_node')
    pub = rospy.Publisher('/task_input', TaskInput, queue_size=10)
    rate = rospy.Rate(0.2)  # 1 message every 5 seconds

    task_inputs = [
        ("morning", 30, 60),
        ("afternoon", 20, 80),
        ("evening", 25, 40)
    ]

    rospy.loginfo("InputNode started. Publishing task inputs...")

    while not rospy.is_shutdown():
        for time_of_day, temp, humid in task_inputs:
            msg = TaskInput()
            msg.time_of_day = time_of_day
            msg.temperature = temp
            msg.humidity = humid
            rospy.loginfo(f"[InputNode] Published: time_of_day={time_of_day}, temperature={temp}, humidity={humid}")
            pub.publish(msg)
            rate.sleep()

if __name__ == '__main__':
    try:
        input_node()
    except rospy.ROSInterruptException:
        pass
