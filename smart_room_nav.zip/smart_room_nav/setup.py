## setup.py
from setuptools import setup

setup(
    name='smart_room_nav',
    version='0.0.0',
    packages=['scripts'],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='mughuntha',
    maintainer_email='mughuntha@todo.todo',
    description='Smart Room Navigation with ML',
    license='MIT',
    tests_require=['pytest'],
)
